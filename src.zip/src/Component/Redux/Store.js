import { applyMiddleware, legacy_createStore as createStore } from "redux";
import Reducer from "./Reducer";
import logger from "redux-logger";
const store = createStore((Reducer));
console.log(store)
export default store