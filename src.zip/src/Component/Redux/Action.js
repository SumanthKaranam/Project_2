import store from "./Store"

function ActionFlag(value){
   return store.dispatch({
    type:'FLAG',
    payload:value
})
}
export default ActionFlag