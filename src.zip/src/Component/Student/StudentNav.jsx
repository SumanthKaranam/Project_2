import React, { useState } from "react";
import { Link } from "react-router-dom";
import Action from "../Redux/Action";
import ActionFlag from "../Redux/Action";
import MenuIcon from "@mui/icons-material/Menu";

export default function StudentNav() {
  const [open, setOpen] = useState(false);
  const handleOpenMenu = () => {
    setOpen(!open);
  };
  return (
    <div>
      <header>
        <nav>
          <Link to="/">
            <img src="Logo.png" className="logo" alt="" />
          </Link>
          <ul>
            <li>
              <Link
                to="/"
                className="nav_item active"
                style={{ textDecoration: "none", color: "white" }}
              >
                Home
              </Link>
            </li>
            <li>
              <Link to="/studentGrades" className="nav_item">
                Grades
              </Link>
            </li>
            <li>
              <Link className="nav_item" onClick={() => ActionFlag(true)}>
                Chat with us
              </Link>
            </li>
            <li>
              <Link Link to="/studentAccount" className="nav_item">
                Account <i className="fa fa-user"></i>
              </Link>
            </li>
            <li>
              <Link to="/" className="nav_item">
                Logout
              </Link>
            </li>
          </ul>
          {open && (
            <div className="student_sidebar">
              <ul>
                <div>
                  <Link
                    to="/"
                    className="nav_item active"
                    style={{ textDecoration: "none", color: "white" }}
                  >
                    Home
                  </Link>
                </div>
                <div>
                  <Link to="/studentGrades" className="nav_item">
                    Grades
                  </Link>
                </div>
                <div>
                  <Link className="nav_item" onClick={() => ActionFlag(true)}>
                    Chat with us
                  </Link>
                </div>
                <div>
                  <Link Link to="/studentAccount" className="nav_item">
                    Account <i className="fa fa-user"></i>
                  </Link>
                </div>
                <div>
                  <Link to="/" className="nav_item">
                    Logout
                  </Link>
                </div>
              </ul>
            </div>
          )}
          <div className="menuIcon" onClick={handleOpenMenu}>
            <MenuIcon />
          </div>
        </nav>
      </header>
    </div>
  );
}
