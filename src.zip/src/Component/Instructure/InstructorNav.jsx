import React, { useState } from "react";
import { Link } from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";

import ActionFlag from "../Redux/Action";

export default function InstructorNav() {
  const [open, setOpen] = useState(false);
  const handleOpenMenu = () => {
    setOpen(!open);
  };
  return (
    <div>
      <header>
        <nav>
          <Link to="/">
            <img src="Logo.png" className="logo" alt="" srcSet="" />
          </Link>
          <ul>
            <li>
              <Link
                to="/instructor"
                className="nav_item active"
                style={{ textDecoration: "none", color: "white" }}
              >
                Home
              </Link>
            </li>
            <li>
              <Link to="/instructorStudentDetails" className="nav_item">
                Students
              </Link>
            </li>
            <li>
              <Link to="/instructorFile" className="nav_item">
                Files
              </Link>
            </li>
            <li>
              <Link to="/instructorAccount" className="nav_item">
                Account <i className="fa fa-user"></i>
              </Link>
            </li>
            <li>
              <Link className="nav_item" onClick={() => ActionFlag(true)}>
                Chat with us
              </Link>
            </li>
            <li>
              <Link to="/" className="nav_item">
                Logout
              </Link>
            </li>
          </ul>
          {open && (
            <div className="student_sidebar">
              <ul>
                <div>
                  <Link
                    to="/instructor"
                    className="nav_item active"
                    style={{ textDecoration: "none", color: "white" }}
                  >
                    Home
                  </Link>
                </div>
                <div>
                  <Link to="/instructorStudentDetails" className="nav_item">
                    Students
                  </Link>
                </div>
                <div>
                  <Link to="/instructorFile" className="nav_item">
                    Files
                  </Link>
                </div>
                <div>
                  <Link to="/instructorAccount" className="nav_item">
                    Account <i className="fa fa-user"></i>
                  </Link>
                </div>
                <div>
                  <Link className="nav_item" onClick={() => ActionFlag(true)}>
                    Chat with us
                  </Link>
                </div>
                <div>
                  <Link to="/" className="nav_item">
                    Logout
                  </Link>
                </div>
              </ul>
            </div>
          )}
          <div className="menuIcon" onClick={handleOpenMenu}>
            <MenuIcon />
          </div>
        </nav>
      </header>
    </div>
  );
}
