import React, { useState } from "react";
import Action from "../Redux/Action";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav>
      <Link to="/">
        <img src="Logo.png" className="logo" alt="" srcSet="" />
      </Link>
      <div className="navbar">
        <ul>
          <li>
            <Link to="/" className="nav_item">
              Home
            </Link>
          </li>
          <li>
            <Link to="student" className="nav_item">
              Student
            </Link>
          </li>
          <li>
            <Link to="instructor" className="nav_item active">
              Instructor
            </Link>
          </li>
          <li>
            <a href="managecoordinator.html" className="nav_item">
              Coordinator
            </a>
          </li>
          <li>
            <a href="manageqa.html" className="nav_item">
              QA-Officer
            </a>
          </li>
          <li>
            <a href="account.html" className="nav_item">
              Account <i className="fa fa-user"></i>
            </a>
          </li>
          <li>
            <a
              className="nav_item"
              style={{ cursor: "pointer" }}
              onClick={() => ActionFlag(true)}
            >
              Chat With Us
            </a>
          </li>
          <li>
            <a href="../../../index.html" className="nav_item">
              Logout
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
}

export default Navbar;
