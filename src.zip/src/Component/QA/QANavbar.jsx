import React, { useState } from "react";
import { Link } from "react-router-dom";
import ActionFlag from "../Redux/Action";
import MenuIcon from "@mui/icons-material/Menu";

export default function QANavbar() {
  const [open, setOpen] = useState(false);
  const handleOpenMenu = () => {
    setOpen(!open);
  };
  return (
    <div>
      <header>
        <nav>
          <Link to="/">
            <img src="Logo.png" className="logo" alt="" srcSet="" />
          </Link>
          <ul>
            <li>
              <Link
                to="/QA"
                className="nav_item active"
                style={{ textDecoration: "none", color: "white" }}
              >
                Home
              </Link>
            </li>
            <li>
              <Link to="/student" className="nav_item">
                Student
              </Link>
            </li>
            <li>
              <Link to="/instructor" className="nav_item">
                Instructor
              </Link>
            </li>
            <li>
              <Link to="/coordinator" className="nav_item">
                Coordinator
              </Link>
            </li>
            <li>
              <a
                className="nav_item"
                style={{ cursor: "pointer" }}
                onClick={() => ActionFlag(true)}
              >
                Chat With Us
              </a>
            </li>
            <li>
              <Link to="/QAAccount" className="nav_item">
                Account <i className="fa fa-user"></i>
              </Link>
            </li>
            <li>
              <Link to="/" className="nav_item">
                Logout
              </Link>
            </li>
          </ul>
          {open && (
            <div className="student_sidebar">
              <ul>
                <div>
                  <Link
                    to="/QA"
                    className="nav_item active"
                    style={{ textDecoration: "none", color: "white" }}
                  >
                    Home
                  </Link>
                </div>
                <div>
                  <Link to="/student" className="nav_item">
                    Student
                  </Link>
                </div>
                <div>
                  <Link to="/instructor" className="nav_item">
                    Instructor
                  </Link>
                </div>
                <div>
                  <Link to="/coordinator" className="nav_item">
                    Coordinator
                  </Link>
                </div>
                <div>
                  <a
                    className="nav_item"
                    style={{ cursor: "pointer" }}
                    onClick={() => ActionFlag(true)}
                  >
                    Chat With Us
                  </a>
                </div>
                <div>
                  <Link to="/QAAccount" className="nav_item">
                    Account <i className="fa fa-user"></i>
                  </Link>
                </div>
                <div>
                  <Link to="/" className="nav_item">
                    Logout
                  </Link>
                </div>
              </ul>
            </div>
          )}
          <div className="menuIcon" onClick={handleOpenMenu}>
            <MenuIcon />
          </div>
        </nav>
      </header>
    </div>
  );
}
