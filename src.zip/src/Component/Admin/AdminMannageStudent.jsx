import React from "react";
import AdminNav from "./AdminNav";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const data = [
  {
    name: "John Mcklain",
    id: "1075325785",
    courseId: "DATA 3402, DATA 4572",
    report: "Progress Tracking",
    grade: "B",
  },
  {
    name: "Agatha Princely",
    id: "1054325785",
    courseId: "DATA 3402, DATA 3892",
    report: "Progress Tracking",
    grade: "A",
  },
];

function AdminManageStudents() {
  return (
    <div>
      <AdminNav />

      <div className="sticky_bar">
        <p>Manage Students</p>
      </div>
      <TableContainer component={Paper} sx={{ width: "80%", margin: "auto" }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Student Name
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Student ID
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Course ID
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Report
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Grade
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {" "}
            {data.map((row, index) => (
              <TableRow
                key={row.name}
                sx={{
                  borderBottom:
                    index === data.length - 1 ? "none" : "1px solid #ddd",
                }}
              >
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.name}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.id}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.courseId}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {" "}
                  <a href="#" target="_blank">
                    <u>{row.report}</u>
                  </a>
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.grade}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  <a href="#">
                    <u>Edit</u>
                  </a>{" "}
                  <a href="#">
                    <u>Delete</u>
                  </a>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}

export default AdminManageStudents;
