import React from 'react';
import AdminNav from './AdminNav';
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const data = [
  {
    name: "John Mcklain",
    id: "1075325785",
    emailId: "jxm785@mavs.uta.edu",
    teach: "DATA 3402, DATA 4572",
    pass: " 80%, 75%",
  },
  {
    name: "Linda Christian",
    id: "1075375785",
    emailId: "lxc785@mavs.uta.edu",
    teach: "DATA 4572",
    pass: "95%",
  },
];

function AdminManageInstructors() {
  return (
    <div>
            <AdminNav/>

      <div className="sticky_bar">
        <p>Manage Instructors</p>
      </div>
      <TableContainer component={Paper} sx={{ width: "80%", margin: "auto" }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
              Instructor Name
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
               Instructor ID
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Email ID
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Course Teach
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
              Class Analytics: Pass %
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {" "}
            {data.map((row, index) => (
              <TableRow
                key={row.name}
                sx={{
                  borderBottom:
                    index === data.length - 1 ? "none" : "1px solid #ddd",
                }}
              >
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.name}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.id}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.emailId}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                <a href="../services.html" target="_blank">
              <u>{row.teach}</u>
            </a>
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                {row.pass} <br />
            <a href="#" target="_blank">
              <u>Analytics Tracking</u>
            </a>
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  <a href="#">
                    <u>Edit</u>
                  </a>{" "}
                  <a href="#">
                    <u>Delete</u>
                  </a>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
     
    </div>
  );
}

export default AdminManageInstructors;
