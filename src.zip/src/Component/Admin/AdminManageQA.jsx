import React from 'react';
import AdminNav from './AdminNav';
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const data = [
  {
    name: "John Mcklain",
    id: "1075325785",
    emailId: "jxm785@mavs.uta.edu",
    programs: "DATA SCIENCE",
    result: "Placements increased by 30%",
  },
  {
    name: "Linda Christian",
    id: "1075375785",
    emailId: "lxc785@mavs.uta.edu",
    programs: "DATA SCIENCE",
    result: "Student Satisfaction with the program is increased.",
  },
];

function AdminManageQA() {
  return (
    <div>
           <AdminNav/>

      <div className="sticky_bar">
        <p>Manage QAs</p>
      </div>

      <TableContainer component={Paper} sx={{ width: "80%", margin: "auto" }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
              QA  Name
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
              QA ID
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Email ID
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
              Contributed Programs
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
              Result
              </TableCell>
              <TableCell sx={{ backgroundColor: "#1a1866", color: "white" }}>
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {" "}
            {data.map((row, index) => (
              <TableRow
                key={row.name}
                sx={{
                  borderBottom:
                    index === data.length - 1 ? "none" : "1px solid #ddd",
                }}
              >
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.name}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.id}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  {row.emailId}
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                <a href="../services.html" target="_blank">
              <u>{row.programs}</u>
            </a>
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                {row.result} <br />
            <a href="#" target="_blank">
              <u>Contributions Tracking</u>
            </a>
                </TableCell>
                <TableCell sx={{ borderRight: "1px solid #ddd" }}>
                  <a href="#">
                    <u>Edit</u>
                  </a>{" "}
                  <a href="#">
                    <u>Delete</u>
                  </a>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}

export default AdminManageQA;
