import React from 'react';
import AdminNav from './AdminNav';

function AdminManageGrades() {
  return (
    <div>
             <AdminNav/>
      <div className="sticky_bar">
        <p>Manage Grade</p>
      </div>

      <table id="table">
        <tr>
          <th>Student name</th>
          <th>Course</th>
          <th>Student Email</th>
          <th>Grade</th>
        </tr>
        <tr>
          <td>User 1</td>
          <td>Course 1</td>
          <td>abac@gamil.com</td>
          <td>A+</td>
        </tr>
        <tr>
          <td>User 1</td>
          <td>Course 1</td>
          <td>abac@gamil.com</td>
          <td>A+</td>
        </tr>
      </table>
    </div>
  );
}

export default AdminManageGrades;
