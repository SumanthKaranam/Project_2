import React, { useState } from "react";
import { Link } from "react-router-dom";
import ActionFlag from "../Redux/Action";
import MenuIcon from "@mui/icons-material/Menu";

function AdminNav() {
  const [open, setOpen] = useState(false);
  const handleOpenMenu = () => {
    setOpen(!open);
  };
  return (
    <div>
      <header>
        <nav>
          <Link to="/">
            <img src="Logo.png" className="logo" alt="" srcSet="" />
          </Link>
          <ul>
            <li>
              <Link
                to="/admin"
                className="nav_item active"
                style={{ textDecoration: "none", color: "white" }}
              >
                Home
              </Link>
            </li>
            <li>
              <Link to="/adminManageStudents" className="nav_item">
                Student
              </Link>
            </li>
            <li>
              <Link to="/adminManageInstructors" className="nav_item">
                Instructor
              </Link>
            </li>

            <li>
              <Link to="/adminManageCoordinator" className="nav_item">
                Coordinator
              </Link>
            </li>
            <li>
              <Link to="/adminManageQA" className="nav_item">
                QA-Officer
              </Link>
            </li>
            <li>
              <Link to="/adminAccount" className="nav_item">
                Account <i className="fa fa-user"></i>
              </Link>
            </li>
            <li>
              <Link
                className="nav_item"
                style={{ textDecoration: "none", color: "white" }}
                onClick={() => ActionFlag(true)}
              >
                Chat with us
              </Link>
            </li>
            <li>
              <Link to="/" className="nav_item">
                Logout
              </Link>
            </li>
          </ul>
          {open && (
            <div className="student_sidebar">
              <ul>
                <div>
                  <Link
                    to="/admin"
                    className="nav_item active"
                    style={{ textDecoration: "none", color: "white" }}
                  >
                    Home
                  </Link>
                </div>
                <div>
                  <Link to="/adminManageStudents" className="nav_item">
                    Student
                  </Link>
                </div>
                <div>
                  <Link to="/adminManageInstructors" className="nav_item">
                    Instructor
                  </Link>
                </div>

                <div>
                  <Link to="/adminManageCoordinator" className="nav_item">
                    Coordinator
                  </Link>
                </div>
                <div>
                  <Link to="/adminManageQA" className="nav_item">
                    QA-Officer
                  </Link>
                </div>
                <div>
                  <Link to="/adminAccount" className="nav_item">
                    Account <i className="fa fa-user"></i>
                  </Link>
                </div>
                <div>
                  <Link
                    className="nav_item"
                    style={{ textDecoration: "none", color: "white" }}
                    onClick={() => ActionFlag(true)}
                  >
                    Chat with us
                  </Link>
                </div>
                <div>
                  <Link to="/" className="nav_item">
                    Logout
                  </Link>
                </div>
              </ul>
            </div>
          )}
          <div className="menuIcon" onClick={handleOpenMenu}>
            <MenuIcon />
          </div>
        </nav>
      </header>
    </div>
  );
}

export default AdminNav;
